export class ChatBot{

    id:any;
    next_action :any;
    message_type: any;
    message: any;
    execution_detail: any;
    payload: any;
    issue_types: any;
    context_id: any;
} 