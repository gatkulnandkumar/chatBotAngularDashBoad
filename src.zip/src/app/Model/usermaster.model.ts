export class UserMaster{

    username:any;
    password: any;
   
} 