import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ChatBot } from 'src/app/Model/chatbot.model';
import { ChatDemoService } from 'src/app/services/chat-demo.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  authenticationError = false;
  showModal = false;

  loginForm = this.fb.group({
    username: [null, [Validators.required]],
    password: [null, [Validators.required]],
    rememberMe: [false],
  });

  //Modal SignUp


  // pass = new FormControl(null, [
  //   (c: AbstractControl) => Validators.required(c),
  //   Validators.pattern(
  //     /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*#?&^_-]).{8,}/
  //   ),
  // ]);
  // cnfpassword = new FormControl(null, [
  //   (c: AbstractControl) => Validators.required(c),
  //   Validators.pattern(
  //     /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@$!%*#?&^_-]).{8,}/
  //   ),
  // ])
  
  signUpForm = this.fb.group({
    uname: [null, [Validators.required]],
    pass:[null, [Validators.required]],
    // cnfpassword: [null, [Validators.required]]
  });
  

  constructor(private fb: FormBuilder, private router: Router, private toastr: ToastrService, private service: ChatDemoService) { }

  ngOnInit(): void {
    localStorage.clear();
    // console.log("this isss singUpForm data===>",this.signUpForm.value);
  }
 

  // login() {
  //   console.log("Reactive form data==>", this.loginForm.get('username')!.value);
  //   this.service.login({
  //     username: this.loginForm.get('username')!.value,
  //     password: this.loginForm.get('password')!.value,
  //     rememberMe: this.loginForm.get('rememberMe')!.value,
  //   }).subscribe((res: any) => {
  //     console.log("token login call::::", res);
  //     if (res == undefined) {
  //       alert("res here is undefined")
  //     }
  //     this.toastr.success('login  Successfully', 'Success', {
  //       timeOut: 2000,
  //     });
  //     this.router.navigate(['/BotCrud']);
  //   },
  //     (error: any) => {
  //       console.error("Error in login:", error);
  //       this.toastr.error('Invalid username and password', 'Error', {
  //         timeOut: 2000,
  //       });
  //       this.router.navigate(['/login']);
  //     }
  //   );
  // }

  Logging() {
    console.log("this.loginForm.value", this.loginForm.value);
    this.service.logging(this.loginForm.value).subscribe(
      (res: any) => {
        console.log("token login call::::", res);

        localStorage.setItem('authenticationToken', res.id_token);
        sessionStorage.setItem('authGaurd', res.id_token);
        console.log("token===>", res.id_token);

        this.toastr.success('login  Successfully', 'Success', {
          timeOut: 2000,
        });
        this.router.navigate(['/BotCrud']);
        // localStorage.clear();
      },
      (error: any) => {
        console.error("Error in login:", error);
        this.toastr.error('Invalid username and password', 'Error', {
          timeOut: 2000,
        });
        this.router.navigate(['/login']);
      }
    );

  }

  clearForm() {
    this.loginForm.reset();
  }

  closeModal() {
    this.showModal = false;
    this.signUpForm.reset();
  }
  openModal() {
    this.showModal = true;
  }
  onSingUp() {
    console.log("this isss singUpForm data===>",this.signUpForm.value.uname);
    const username = this.signUpForm.value.uname;
    const password = this.signUpForm.value.pass;

    console.log("this username password singUpForm data===>",username, password);
    // Create the payload object with the correct structure
    const payload = {
      username: username,
      password: password
    };

    console.log("payload is here===>",payload);
    console.log("this isss singUpForm data===>",this.signUpForm.value.uname);
    this.service.signUp(payload).subscribe(
      (res: any) => {
        console.log("insertUserData login call::::", res);

        this.toastr.success('Register  Successfully', 'Success', {
          timeOut: 2000,
        });
        this.showModal = false;
        this.signUpForm.reset();
        this.router.navigate(['/login']);
      },
      (error: any) => {
        console.error("Error in login:", error);
        this.toastr.error('Unable to Register', 'Error', {
          timeOut: 2000,
        });
        this.router.navigate(['/login']);
      }
    );
  }
  cancel() {
    this.showModal = false; 
    this.signUpForm.reset();
    this.router.navigate(['/login']);
  }

}
